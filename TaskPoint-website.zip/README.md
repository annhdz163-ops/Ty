# TaskPoint Demo

Mở `index.html` bằng trình duyệt để chạy bản demo.

Tính năng:
- Hiển thị điểm.
- Danh sách nhiệm vụ.
- Hoàn thành nhiệm vụ nhận điểm.
- Lưu điểm bằng localStorage.
- Đổi điểm lấy phần thưởng mẫu.

Để triển khai thật cần thêm backend/database, đăng nhập, xác thực nhiệm vụ,
chống gian lận, lịch sử giao dịch và hệ thống quản trị.
